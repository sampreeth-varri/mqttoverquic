<!--
.. title: Mosquitto for Slackware
.. slug: mosquitto-for-slackware
.. date: 2011-01-31 09:04:13
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Chris Willing of the University of Queensland has very kindly put together some
mosquitto packages for Slackware 13.0 and 13.1 as well as instruction on how to
build your own packages.

The packages and instructions are here:
<http://www.vislab.uq.edu.au/howto/mqtt/index.html> I've also put the link on
the downloads page.

Thanks Chris!
