<!--
.. title: Version 0.14.1 released
.. slug: version-0-14-1-released
.. date: 2011-11-21 16:22:01
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

 * Fix Python syntax errors (bug #891673).
