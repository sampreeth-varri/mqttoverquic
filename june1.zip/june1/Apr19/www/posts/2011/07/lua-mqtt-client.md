<!--
.. title: Lua MQTT client
.. slug: lua-mqtt-client
.. date: 2011-07-29 07:42:28
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

Andy Gelme [reports] that his Lua MQTT client is ready for use. The downloads,
installation and usage instructions, example code and api information are all
available at <https://github.com/geekscape/mqtt_lua>.  I particularly like the
image of it running on a PSP.

Well done Andy!

I wonder what the next language to get MQTT support will be?

[reports]: https://twitter.com/#%21/geekscape/status/96710950979256323
