<!--
.. title: Wireshark MQTT decoder
.. slug: wireshark-mqtt-decoder
.. date: 2011-07-05 13:23:42
.. tags: Solutions
.. category:
.. link:
.. description:
.. type: text
-->

If you're trying to debug your MQTT connection, you may be interested in
something Karl P has written - an MQTT decoder/dissector for Wireshark. It
doesn't have complete protocol support yet, but is a good start.

 * <http://false.ekta.is/2011/06/mqtt-dissector-decoder-for-wireshark/>
