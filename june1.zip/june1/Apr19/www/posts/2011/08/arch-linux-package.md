<!--
.. title: Arch Linux package
.. slug: arch-linux-package
.. date: 2011-08-16 09:49:18
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Gordon Pearce has packaged Mosquitto on Arch Linux through an Arch User
Repository. The package details are at
<http://aur.archlinux.org/packages.php?ID=51571>

Thanks Gordon!
