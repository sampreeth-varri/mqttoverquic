<!--
.. title: MQTT Standardisation
.. slug: mqtt-standardisation
.. date: 2011-08-15 20:31:10
.. tags: MQTT
.. category:
.. link:
.. description:
.. type: text
-->

IBM have announced that MQTT is to be formally standardised. If you're
interested in taking part in the process, there are full details at
<http://mqtt.org/2011/08/open-invitation-to-join-the-mqtt-standardization-discussion>
