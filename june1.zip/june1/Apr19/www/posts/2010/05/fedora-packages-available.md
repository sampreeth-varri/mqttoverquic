<!--
.. title: Fedora packages available
.. slug: fedora-packages-available
.. date: 2010-05-14 15:43:10
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Thanks to help from Chris Procter, there are now rpm packages available for
Fedora Linux. As these are the first rpm packages, there may be problems so
please report back if you find any.

There are details on where to get the packages on the [download page].

Users of other rpm based distributions are currently out of luck - the versions
of sqlite that they provide are typically either too old or else don't have
support for some required features compiled in.

Thanks to everybody else who got in touch about rpms as well!

[download page]: /download
