<!--
.. title: Updating password files
.. slug: updating-password-files
.. date: 2012-09-09 21:41:25
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

Mosquitto 1.0 introduced the use of password files with hashed passwords but
had no way to convert from the old plain text password files. This feature will
be available in version 1.1 but if it is important to you then you can already
get the updated code for the mosquitto_passwd utility at
<https://bitbucket.org/oojah/mosquitto/src/3b8ef11cf687>
