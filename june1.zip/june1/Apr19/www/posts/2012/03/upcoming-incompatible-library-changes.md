<!--
.. title: Upcoming incompatible library changes
.. slug: upcoming-incompatible-library-changes
.. date: 2012-03-06 07:37:31
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

Version 0.16 of the mosquitto client libraries will have some binary
incompatible changes to their APIs. This means that it is a good time to make
other changes that are incompatible. If you think any part of the interface
(see <http://mosquitto.org/api/>) is crazy or could be improved in any way,
please get in touch or add a comment below.
