<!--
.. title: Baby
.. slug: baby
.. date: 2012-08-22 10:41:07
.. tags: Releases,Support
.. category:
.. link:
.. description:
.. type: text
.. author: Roger
-->

[![baby](/blog/uploads/2012/08/IMAG0006-300x199.jpg)](/blog/uploads/2012/08/IMAG0006.jpg)

I've recently become a father, so please don't be offended if I take a while to
respond to any mosquitto related queries.
