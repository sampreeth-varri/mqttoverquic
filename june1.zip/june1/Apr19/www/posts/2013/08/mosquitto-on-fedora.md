<!--
.. title: Mosquitto on Fedora
.. slug: mosquitto-on-fedora
.. date: 2013-08-15 20:24:04
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Mosquitto has been packaged for Fedora thanks to Rich Mattes. Fedora 19 users
will be able to install with "yum install mosquitto".

Thanks Rich!
