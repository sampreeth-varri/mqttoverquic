<!--
.. title: MQTT standardisation - OASIS call for participation
.. slug: mqtt-standardisation-oasis-call-for-participation
.. date: 2013-02-04 20:35:31
.. tags: Events,MQTT
.. category:
.. link:
.. description:
.. type: text
-->

The MQTT protocol is going for standardisation at OASIS. A technical committee
is being formed and there is a call for participation for interested parties.
There are details at the link below:

<https://www.oasis-open.org/news/announcements/call-for-participation-message-queuing-telemetry-transport-mqtt-tc">

The plan seems to be to take the 3.1 spec as it is for standardisation and see
about changes in the future. If you are interested in taking part see the link
above, but note that you need to be a paid up member of
OASIS.
