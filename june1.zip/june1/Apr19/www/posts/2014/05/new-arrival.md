<!--
.. title: New arrival
.. slug: new-arrival
.. date: 2014-05-27 23:29:39
.. tags: Releases
.. category: releases
.. link:
.. description:
.. type: text
.. author: Roger
-->

I'm pleased to say that I'm a new father again. My 7lb 12 (3.57kg) boy arrived
today and is quite happy, as is his mother.

Apologies to anybody who has emailed me recently and I've not yet replied -
this is the main reason!

[![baby][baby]](/blog/uploads/2014/05/14098345978_c15d12f19a_z.jpg)

[baby]:/blog/uploads/2014/05/14098345978_c15d12f19a_z-300x200.jpg
